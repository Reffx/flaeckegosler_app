import 'package:flutter/material.dart';

class FasnachtsDate {
  final String start;
  final String end;

 FasnachtsDate(
      {@required this.start,
      @required this.end,
      });
}
