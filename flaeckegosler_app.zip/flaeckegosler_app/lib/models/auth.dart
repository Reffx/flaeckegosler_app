enum AuthMode {
  Signup,
  Login
}